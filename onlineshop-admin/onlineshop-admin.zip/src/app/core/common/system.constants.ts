export class SystemConstants{
    public static CURRENT_USER = "CURRENT_USER";
    public static BASE_API = "http://localhost:5000/";
    // public static BASE_API = "http://tedushopapi.tedu.com.vn/";
}